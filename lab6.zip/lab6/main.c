#include <stdio.h>

void swap_1(int* a, int* b)
{
    *a = *a ^ *b;// x now becomes 15
    *b = *a ^ *a;// y becomes 10
    *a = *a ^ *b;// x becomes 5
}
void swap_2(int* a, int* b)
{
    *a = *a + *b; // x now becomes 15
    *b = *a - *b; // y becomes 10
    *a = *a - *b; // x becomes 5
}
void swap_3(int* a, int* b)//10 5
{
    if(*b==0){
        *b=*a;
        *a=0;
    }else if(*a==0){
        *a=*b;
        *b=0;
    }else{
    *a = *a * *b; // x now becomes 50
    *b = *a / *b; // y becomes 50/5==>10
    *a = *a / *b; // x becomes 50/10==>5
    }

}
int main()
{
    int x ;
    int y;
    //printf("After swap(&x, &x): x = %d", x);
    printf("Enter the first number x: ");
    scanf("%d",&x);
    printf("Enter the first number y: ");
    scanf("%d",&y);
    swap_3(&x, &y);

    printf("After swap(&x, &y): x = %d\n", x);
    printf("After swap(&x, &y): y = %d\n", y);
    return 0;
}
