#include <iostream>
#include <graphics.h>
using namespace std;

class Point
{
    int x,y;
    public:
        void set_x(int _x){
            x=_x;
        }
        void set_y(int _y){
        y= _y;
        }
        void set_xy(int _x, int _y){
            x=_x;
            y=_y;
        }
        int getX(){
            return x;
        }
         int getY(){
            return y;
        }
        void paint(){
            cout<<"("<<x<<","<<y<<")"<<endl;
        }
        Point(int _x,int _y){
            x=_x;
            y=_y;
        }
        Point(){
            x=0;
            y=0;
            cout<<"constructor point"<<endl;
        };
        ~Point(){
            cout<<"Destroy Point"<<endl;
        }
};

class Line
{
    Point lp1,lp2;
    Point *ptr1,*ptr2;
    public:
        Line():lp1(0,0),lp2(0,0){
            ptr1=NULL;
            ptr2=NULL;
        }
        Line(int p1x,int p1y, int p2x,int p2y):lp1(p1x,p1y),lp2(p2x,p2y){

        }
      /* Line(Point p1, Point p2){
            lp1=p1;
            lp2=p2;
        }*/
        void drawLine(){

	    line(lp1.getX(),lp1.getY(),lp2.getX(),lp2.getY());

	    }
        void setPoints(Point *p1,Point *p2){
            ptr1=p1;
            ptr2=p2;
        }
        void set_lp1(int _x, int _y){
            lp1.set_xy(_x,_y);
        }
        void set_lp2(int _x, int _y){
            lp2.set_xy(_x,_y);
        }
        void paintLine(){
            lp1.paint();
            lp2.paint();
        }
        void paintLine(Point p1,Point p2){//assoication
            p1.paint();
            p2.paint();
        }
        void paintLine2(){//assoication
           if(ptr1!=NULL&&ptr2!=NULL){
            ptr1->paint();
            ptr2->paint();
           }
        }
        ~Line(){
            cout<<"Destroy Line"<<endl;
        }
};

class Circle{
    Point p;
    Point *ptr;
    int radius;
public:
    Circle():p(0,0){
        //p.set_xy(0,0);
        radius=0;
    }
    Circle(int px,int py, int _radius){
            p.set_xy(px,py);
            radius=_radius;
        }
    void drawCircle(){
	    circle(p.getX(),p.getY(), radius);
	}
    void set_p(int _x,int _y){
            p.set_xy(_x,_y);
        }
    void set_radius(int _radius){
        radius= _radius;
        }
    void set_circlePara(int x,int y ,int _radius){
          p.set_xy(x,y);
          radius= _radius;
    }
    void enterPoint(Point *p){
     ptr=p;
    }
    void paintCircle2(){
        ptr->paint();
        cout<<radius<<endl;
    }
    void paintCircle(){
        p.paint();
        cout<<radius<<endl;
    }
    void paintCircle(Point x){//assoication
        x.paint();
        cout<<radius<<endl;
    }
    ~Circle(){
         cout<<"Destroy circle"<<endl;
    }


};

int main()
{

    int gd  = DETECT , gm;
    initgraph(&gd,&gm,(char*)"");

    Line l1(5,7,125,144);
    l1.drawLine();
    Circle c1(150,150,100);
    c1.drawCircle();

    getch();
    closegraph();
    //Point p1(20,20);
    //Point p2(10,10);
    //Line l1;
   // Line l(2,3,4,5);
   /// l.paintLine();
    //l1.setPoints(&p1,&p2);
    //l1.paintLine2();
   // cout << "Hello world!" << endl;
  // Circle c1;
   //c1.set_circlePara(5,6,2);
  // c1.paintCircle();
  // Point p1(10,20);
  // c1.enterPoint(&p1);
   //c1.paintCircle2();
   ///Point p2 (50,50);
   //c1.paintCircle(p2);
    return 0;
}
