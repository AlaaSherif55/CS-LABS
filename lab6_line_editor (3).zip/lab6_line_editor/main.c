#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <dos.h>
#include <dir.h>
#define LEFT_ARROW 75
#define RIGTH_ARROW 77
#define BACKSPACE 8
#define ESC 27
#define ADD 43
#define MAX_SIZE 50
int position=0;
void SetColor(int ForgC);
void gotoxy(int x,int y);
void delete_element(char *string);
int string_length(char array2[]);
void line_editor();
void operation(char c);
void design();
int length=0;
char ch;

char string[MAX_SIZE];

void line_editor(){
    gotoxy(0,0);
    printf("=================line editor=====================");
    gotoxy(0,4);
    printf("=================================================");
    operation(ch);
}
void design(){
    gotoxy(0,0);
    printf("=================line editor=====================");
    gotoxy(0,4);
    printf("=================================================");
    gotoxy(0,2);
}
int main(){

    //line_editor();
    //system("cls");
    line_editor();

    return 0;
}
void operation(char c){
    gotoxy(0,2);
    while(1)
    {
        fflush(stdin);
        ch=getch();
        fflush(stdin);



        //gotoxy(position,2);
        //printf("%c",ch);
        //printf("%s",string);
        if(ch==-32)
        {
            ch=getch();//extended
            switch((int)ch)
            {
            case LEFT_ARROW:

                position--;

                if(position<0)
                {
                    position=0;
                }
                // gotoxy(5,7);
                //     system("cls");
                gotoxy(position,2);
                // printf("\n \n %d", position);
                break;
            case RIGTH_ARROW:
                position++;
                if(position>length&&position<MAX_SIZE ) //alaa
                {
                    position=length;
                }
                //printf("\n\n %d",position);
                //gotoxy(10,9);
                //system("cls");
                //printf("%s",string);
                gotoxy(position,2);
                // gotoxy(9,9);
                //printf("\n \n%d", position);

                break;

            }
        }
        else
        {
            //gotoxy(position,2);
            // printf("%c",ch);
            int length= string_length(string);
            if((ch>='a'&&ch<='z'||ch>='A'&&ch<='Z'||ch==' ')&&length<= MAX_SIZE)
            {
                string[position]=ch;
                gotoxy(position,2);
                system("cls");
                design();
                printf("%s",string);
                position++;

            }
            else
            {
                switch((int)ch)
                {
                case BACKSPACE:
                    position--;
                    if(position<0){
                        position=0;
                    }
                    delete_element(string);
                    system("cls");
                    design();
                    printf("%s",string);
                    gotoxy(position,2);
                    //system("cls");
                    //display_get_position();
                    break;
                case ESC:
                    exit(0);
                    break;
                }

            }


        }
    }
}
void SetColor(int ForgC){
    WORD wColor;

    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO csbi;

    //We use csbi for the wAttributes word.
    if(GetConsoleScreenBufferInfo(hStdOut, &csbi))
    {
        //Mask out all but the background attribute, and add in the forgournd     color
        wColor = (csbi.wAttributes & 0xF0) + (ForgC & 0x0F);
        SetConsoleTextAttribute(hStdOut, wColor);
    }
    return;
}
void gotoxy(int x,int y){
    COORD coord= {0,0};
    coord.X=x;
    coord.Y=y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}
void delete_element(char *string){
    int length=string_length(string);
    for(int i=position; i<=length; i++)
    {
        if(i==length-1)
        {
            string[i]='\0';
        }
        string[i]=string[i+1];

    }
}
int string_length(char array2[]){
    int length=0;
    while(array2[length]!='\0')
    {
        length++;
    }
    return length;
}

//<== position --
//==> position ++
//backspace to alert to delete character
//alaa
//if(length==100)
//+ to alert to insert
//esc to alert finishing adding character
//alaa

