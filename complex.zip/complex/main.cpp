#include <iostream>

using namespace std;
class Complex{
 private:
    int real;
    int image;
 public:
    Complex(int r=0,int i=0){
        real=r;
        image=i;
    }
    void setReal(int r){
        real=r;
    }
    void setComplex(int r,int i ){
          real=r;
          image=i;
    }
    void setImage(int i){
        image=i;
    }
    int getReal()const{
        return real;
    }
    int getImage()const{
        return image;
    }
     void print(){
        cout<<"The number: "<<real;
        if(image>0){
            cout<<"+"<<image<<"j";
        }else if(image<0){
             cout<<image<<"j";
        }
    }
    Complex add(Complex c);
    //c5=c3+c2
    Complex operator +(const Complex &c){
      Complex res(real+c.getReal(),image+c.getImage());
      return res;
    }
     //c5=c3-c2
    Complex operator -(const Complex &c){
      Complex res(real-c.getReal(),image-c.getImage());
      return res;
    }
    //c5+=c2===>c5=c5+c2
    Complex operator +=(const Complex &c){
    real=real+c.getReal();
    image=image+c.getImage();
    return *this;
    }
    //c5-=c2===>c5=c5-c2
    Complex operator +=(Complex &c){
    real=real+c.getReal();
    image=image+c.getImage();
    return *this;
    }
   //c5=c3+10
   Complex operator +(int i){
   Complex res(real+i,image);
      return res;
   }
   //c3==c2
   int operator ==(const Complex &c){
     return real==c.real&&image==c.image;
   }

//c1[1] --> image  --> overloading [1]
//c1[0] --> Real --> overloading [0]
   int operator [](int i){
      if(i==0){
        return real;
      }else{
        return image;
      }
   }
    int operator [](char *a){//image c2["image"}
      if(a[0]=='i',a[1]=='m',a[2]=='a',a[3]=='g',a[4]=='e'){
       return image;
      }
      if(a[0]=='r',a[1]=='e',a[2]=='a',a[3]=='l'){

        return real;
      }
      return 0;
   }
     //++c5 prefix
  Complex operator ++(){
      real=real+1;
      return *this;
   }

    //c5++ postfix
   Complex operator ++(int){
      Complex temp=*this;
      real=real+1;
      return temp;
   }
     //--c5 prefix
   Complex operator --(){
      real=real-1;
      return *this;
   }
    //c5-- postfix
   Complex operator --(int){
      Complex temp=*this;
      real=real-1;
      return temp;
   }
   operator float(){
       return real;
   }
   //friend ostream & operator << (ostream &out, const Complex &c);
   friend istream & operator >> (istream &in,  Complex &c);
};//end of class
ostream & operator << (ostream &out, const Complex &c)//cout<<
{
    out << c.getReal();
    out << "+i" << c.getImage() << endl;
    return out;
}

istream & operator >> (istream &in,  Complex &c)
{
    in >> c.real;
    in >> c.image;
    return in;
}

//c5=10+c2
Complex operator +(int i, Complex &c){
   Complex res(c.getReal()+i,c.getImage());
    return res;
    }
//c5=10-c2
Complex operator -(int i, Complex &c){
   Complex res(c.getReal()-i,c.getImage());
    return res;
    }
Complex Complex::add(Complex c){
      Complex res;
      res.setImage(image+c.getImage());
      res.setReal(real+c.getReal());
      return res;
    }
Complex addStandAlone(Complex c,Complex y){
      Complex res;
      res.setImage(y.getImage()+c.getImage());
      res.setReal(y.getReal()+c.getReal());
      return res;
}
Complex subStandAlone(Complex c,Complex y){
      Complex res;
      res.setImage(c.getImage()-y.getImage());
      res.setReal(c.getReal()-y.getReal());
      return res;
    }
 void printStandAlone(Complex c ){
        cout<<"The number: "<<c.getReal();
        if(c.getImage()>0){
            cout<<"+"<<c.getImage()<<"j";
        }else if(c.getImage()<0){
             cout<<c.getImage()<<"j";
        }
}
/*Complex sub(Complex c,Complex x){
      Complex res;
      res.image=c.image-x.image;
      res.real=c.real-x.real;
      return res;
}*/
int main()
{
   Complex c1(10,10),c2(20,20);
   cout<<endl<<"=================================="<<endl;
     Complex c5(1,3);
    //cin>>c5;
   // cout<<c5;
   //cout<<c5["image"]<<endl;//3
   //cout<<c5["real"]<<endl;//1

  // c5=c1+c2;//c1.operator x(c2)
  // c5.print();//c5(30,30)
   //c5+=c1;//c5=c5+c1;40,40
   //cout<<endl;
   //c5.print();
   //c5=c5+10;//50,40
   //cout<<endl;
  // c5.print();
  // c5=10+c2;//30,20
  // cout<<endl;
   //c5.print();
   //Complex x1(20,20),x2(20,20);
   //cout<<(x1==x2);
  // c5=c1+c2;
   //Complex i=x.add(u);
   //cout<<i.getReal()<<"\n";
   //cout<<i.getImage()<<"\n";
  // c5=c2++;
  // c5.print();
  // c2.print();
  // c5=(float)c2;
  // c5.print();
    return 0;
}




